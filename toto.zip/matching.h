#pragma once
#include <Imagine/Graphics.h>
using namespace Imagine;
#include "pixel.h"
