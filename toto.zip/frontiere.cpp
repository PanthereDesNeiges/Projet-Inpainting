#include "frontiere.h"
#include <cmath>
using namespace std;
#include <Imagine/Graphics.h>
using namespace Imagine;

void frontiere::add_frontiere(){

}

void frontiere::initialize_frontiere(){

}

void frontiere::pop_frontiere(){

}

pixel frontiere::max_priority(){

}
