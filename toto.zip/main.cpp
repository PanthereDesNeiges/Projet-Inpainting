// Imagine++ project
// Project:  Projet S2
// Student(s): Philomène Boisnard, Erwann Estève, Wandrille Flamant, Sixtine  Nodet

#include <Imagine/Graphics.h>
using namespace Imagine;
#include "pixel.h"


const int width = 512, height = 512;


int main() {
	openWindow(width,height);


	endGraphics();
	return 0;
}
